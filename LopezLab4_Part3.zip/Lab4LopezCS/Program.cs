﻿using System;

namespace Lab4LopezCS
{
    class Program
    {   //Michael Lopez
        //Lab 4
        //SE 245 - C#
        public class Person //EDITED FOR PART TWO OF LAB 4 -- CONVERT TO CLASS
        {
            //person struct initiated
            private string fName;
            private string lName;
            private string mName;
            private string street1;
            private string street2;
            private string city;
            private string state;
            private int zipCode;
            private int phoneNumber; //edited for part two - numbers only
            private string email;

            public string FName
            {
                get
                {
                    return fName;
                }
                set
                {
                    if (BasicTools.GotBadWords(value)) 
                    { 
                        fName = value;
                    }
                    else
                    {
                        fName = "POOPY IS THE RIGHT ANSWER??";
                    }
                }
            }
            public string LName
            {
                get
                {
                    return lName;
                }
                set
                {
                    lName = value;
                }
            }
            public string MName
            {
                get
                {
                    return mName;
                }
                set
                {
                    mName = value;
                }
            }
            public string Street1
            {
                get
                {
                    return street1;
                }
                set
                {
                    street1 = value;
                }
            }
            public string Street2
            {
                get
                {
                    return street2;
                }
                set
                {
                    street2 = value;
                }
            }
            public string City
            {
                get
                {
                    return city;
                }
                set
                {
                    city = value;
                }
            }
            public string State
            {
                get
                {
                    return state;
                }
                set
                {
                    state = value;
                }
            }
            public int Zip
            {
                get
                {
                    return zipCode;
                }
                set
                {
                    zipCode = value;
                }
            }
            public int Phone
            {
                get
                {
                    return phoneNumber;
                }
                set
                {
                    phoneNumber = value;
                }
            }
            public string Email
            {
                get
                {
                    return email;
                }
                set
                {
                    if (BasicTools.IsValidEmail(value))
                    {
                        email = value;
                    }
                    else
                    {
                        email = "INVALID";
                    }
                }
            }
        }
        static void Main(string[] args)
        {
            bool boolRslt = false; //we use this bool to make sure the info the user gives us is valid

            Person temp = new Person();
            //Prompting user for information to log

            Console.Write("\nPlease Enter First Name: "); //"poopy" is allowed, showing weakness in public strings
            temp.FName = Console.ReadLine();


            Console.Write("\nPlease Enter Last Name: ");
            temp.LName = Console.ReadLine();


            Console.Write("\nPlease Enter Middle Name: ");
            temp.MName = Console.ReadLine();


            Console.Write("\nPlease Enter Street Address: ");
            temp.Street1 = Console.ReadLine();


            Console.Write("\nPlease Enter Second Street Address (If Applicable): ");
            temp.Street2 = Console.ReadLine();


            Console.Write("\nPlease Enter City: ");
            temp.City = Console.ReadLine();


            Console.Write("\nPlease Enter State: ");
            temp.State = Console.ReadLine();

            //do
            //{
            //    Console.Write("\nPlease Enter Zip Code: ");
            //    boolRslt = Int32.TryParse(Console.ReadLine(), out temp.Zip);

            //    if (boolRslt == false)
            //    {
            //        Console.WriteLine("\nERROR: Please input 5 Digit Zip Code [EX. 02909]");
            //    }
            //} while (boolRslt == false);

            //do //edited for part two - numbers only
            //{
            //    Console.Write("\nPlease Enter Phone Number: ");
            //    boolRslt = int32.TryParse(Console.ReadLine(), out temp.Phone);

            //    if (boolRslt == false)
            //    {
            //        Console.WriteLine("\nERROR: Please input 10 Digit Number WITHOUT DASHES [EX. 4011234567]");
            //    }
            //} while (boolRslt == false);


            Console.Write("\nPlease Enter Email: ");
            temp.Email = Console.ReadLine();

            //DISPLAYING INFO   
            Console.Write("\n\t The Person We Have Created: ");
            Console.Write($"\nFirst Name: {temp.FName}");
            Console.Write($"\nMiddle Name: {temp.MName}");
            Console.Write($"\nLast Name: {temp.LName}");
            Console.Write($"\n1st Street Address: {temp.Street1}");
            Console.Write($"\nOther Street Address: {temp.Street2}");
            Console.Write($"\nCity: {temp.City}");
            Console.Write($"\nState: {temp.State}");
            Console.Write($"\nZip Code: {temp.Zip}");
            Console.Write($"\nPhone Number: {temp.Phone}");
            Console.Write($"\nEmail: {temp.Email}");

            BasicTools.Pause();
        }
    }
}
