﻿using System;

namespace Lab4LopezCS
{
    class Program
    {   //Michael Lopez
        //Lab 4
        //SE 245 - C#
        class Person //EDITED FOR PART TWO OF LAB 4 -- CONVERT TO CLASS
        {
            //person struct initiated
            public string fName;
            public string lName;
            public string mName;
            public string street1;
            public string street2;
            public string city;
            public string state;
            public int zipCode;
            public int phoneNumber; //edited for part two - numbers only
            public string email;

        }
        static void Main(string[] args)
        {
            bool boolRslt = false; //we use this bool to make sure the info the user gives us is valid

            Person temp = new Person();
            //Prompting user for information to log

            Console.Write("\nPlease Enter First Name: "); //"poopy" is allowed, showing weakness in public strings
            temp.fName = Console.ReadLine();


            Console.Write("\nPlease Enter Last Name: ");
            temp.lName = Console.ReadLine();


            Console.Write("\nPlease Enter Middle Name: ");
            temp.mName = Console.ReadLine();


            Console.Write("\nPlease Enter Street Address: ");
            temp.street1 = Console.ReadLine();


            Console.Write("\nPlease Enter Second Street Address (If Applicable): ");
            temp.street2 = Console.ReadLine();


            Console.Write("\nPlease Enter City: ");
            temp.city = Console.ReadLine();


            Console.Write("\nPlease Enter State: ");
            temp.state = Console.ReadLine();

            do
            {
                Console.Write("\nPlease Enter Zip Code: ");
                boolRslt = Int32.TryParse(Console.ReadLine(), out temp.zipCode);

                if (boolRslt == false)
                {
                    Console.WriteLine("\nERROR: Please input 5 Digit Zip Code [EX. 02909]");
                }
            } while (boolRslt == false);

            do //edited for part two - numbers only
            {
                Console.Write("\nPlease Enter Phone Number: ");
                boolRslt = Int32.TryParse(Console.ReadLine(), out temp.phoneNumber);

                if (boolRslt == false)
                {
                    Console.WriteLine("\nERROR: Please input 10 Digit Number WITHOUT DASHES [EX. 4011234567]");
                }
            } while (boolRslt == false);


            Console.Write("\nPlease Enter Email: ");
            temp.email = Console.ReadLine();

            //DISPLAYING INFO   
            Console.Write("\n\t The Person We Have Created: ");
            Console.Write($"\nFirst Name: {temp.fName}");
            Console.Write($"\nMiddle Name: {temp.mName}");
            Console.Write($"\nLast Name: {temp.lName}");
            Console.Write($"\n1st Street Address: {temp.street1}");
            Console.Write($"\nOther Street Address: {temp.street2}");
            Console.Write($"\nCity: {temp.city}");
            Console.Write($"\nState: {temp.state}");
            Console.Write($"\nZip Code: {temp.zipCode}");
            Console.Write($"\nPhone Number: {temp.phoneNumber}");
            Console.Write($"\nEmail: {temp.email}");

            BasicTools.Pause();
        }
    }
}
